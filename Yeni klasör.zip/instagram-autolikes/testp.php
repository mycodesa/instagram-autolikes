<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$api_key = '49dc3507e7f165416d32cfe68194391e'; // Instagram API anahtarınız
$instagram_user_id = '1052023069'; // Test etmek istediğiniz Instagram kullanıcı ID'si
$end_cursor = ''; // İlk sayfa için boş bırakabilirsiniz. Sonraki sayfalara geçmek için geçerli bir end_cursor değeri gereklidir.

$posts_api_url = "https://api.instagapi.com/userreels/{$instagram_user_id}/10/{$end_cursor}";

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $posts_api_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-InstagAPI-Key: $api_key"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    echo "cURL Hatası #: " . $err . "\n";
} else {
    $posts_data = json_decode($response, true);

    if (!isset($posts_data['data']['items']) || $posts_data['status'] !== 'ok') {
        echo "API Hatası: Kullanıcı: $instagram_user_id\nAPI Yanıtı: " . (isset($posts_data['message']) ? $posts_data['message'] : 'Bilinmeyen hata') . "\n";
    } else {
        echo "Kullanıcı: $instagram_user_id\n";
        echo "Reels Videoları:\n";

        foreach ($posts_data['data']['items'] as $post) {
            $post_date = new DateTime('@' . $post['media']['taken_at']);
            $post_date->setTimezone(new DateTimeZone('Europe/Istanbul'));
            $formatted_date = $post_date->format('Y-m-d H:i:s');
            echo "$formatted_date - https://www.instagram.com/p/" . $post['media']['code'] . "/\n";
        }
    }
}
?>
